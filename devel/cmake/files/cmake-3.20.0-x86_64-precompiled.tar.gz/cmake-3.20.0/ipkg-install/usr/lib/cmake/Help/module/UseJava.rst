.. cmake-module:: ../../Modules/UseJava.cmake
