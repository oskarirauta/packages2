UseJavaClassFilelist
--------------------

.. versionchanged:: 3.20
  This module was previously documented by mistake and was never meant for
  direct inclusion by project code.  See the :module:`UseJava` module.
