.. cmake-module:: ../../Modules/FindSQLite3.cmake
